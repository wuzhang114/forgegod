package com.forgegod.ai;

import net.minecraftforge.fml.loading.FMLPaths;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Properties;

/** Local client-side configuration for the optional cloud provider. Never logs or broadcasts the key. */
public final class ApiKeyStore {
    private static final String FILE_NAME = "forgegod-client.properties";
    private static final String KEY_NAME = "deepseek_api_key";

    private ApiKeyStore() { }

    public static String resolve() {
        String environment = System.getenv("DEEPSEEK_API_KEY");
        if (environment != null && !environment.isBlank()) return environment.trim();
        return readStoredKey();
    }

    public static boolean hasEnvironmentKey() {
        String environment = System.getenv("DEEPSEEK_API_KEY");
        return environment != null && !environment.isBlank();
    }

    public static String readStoredKey() {
        try {
            Path path = configPath();
            if (!Files.exists(path)) return "";
            Properties properties = new Properties();
            try (var reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
                properties.load(reader);
            }
            return properties.getProperty(KEY_NAME, "").trim();
        } catch (IOException | RuntimeException ignored) {
            return "";
        }
    }

    public static boolean saveStoredKey(String key) {
        String normalized = key == null ? "" : key.trim();
        if (normalized.length() > 512 || normalized.contains("\r") || normalized.contains("\n")) return false;
        try {
            Path path = configPath();
            Files.createDirectories(path.getParent());
            Properties properties = new Properties();
            if (!normalized.isBlank()) properties.setProperty(KEY_NAME, normalized);
            try (var writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)) {
                properties.store(writer, "ForgeGod local AI settings");
            }
            return true;
        } catch (IOException | RuntimeException ignored) {
            return false;
        }
    }

    public static boolean clearStoredKey() {
        try {
            return Files.deleteIfExists(configPath());
        } catch (IOException | RuntimeException ignored) {
            return false;
        }
    }

    public static String sourceLabel() {
        if (hasEnvironmentKey()) return "环境变量 DEEPSEEK_API_KEY";
        return readStoredKey().isBlank() ? "未配置" : "本机配置文件";
    }

    private static Path configPath() {
        return FMLPaths.CONFIGDIR.get().resolve(FILE_NAME);
    }
}
